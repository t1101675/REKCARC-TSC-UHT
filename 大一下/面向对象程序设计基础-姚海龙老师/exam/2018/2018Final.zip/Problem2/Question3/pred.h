#ifndef PRED_H_
#define PRED_H_

#include <cstring>

class PredI {
public:
  bool operator() (const char* s1, const char* s2) {
    if (strcmp(s1, s2) < 0) return true;
    else return false;
  }
};

class PredND {
public:
  bool operator() (const char* s1, const char* s2) {
    if (strcmp(s1, s2) <= 0) return true;
    else return false;
  }
};


#endif //PRED_H_
