#ifndef LIST_H_
#define LIST_H_
#include <vector>
#include <iostream>
#include <cmath>

template <typename T, typename Pred>
class LISTS {
public:
  void solve(const std::vector<T>& numVec, std::vector<int>& posIndex);
};

template <typename T, typename Pred>
void LISTS<T, Pred>::solve(const std::vector<T>& numVec, std::vector<int>& posIndex) {
  int n = numVec.size();
  int* P = new int[n];
  for (int i = 0; i < n; i++) P[i] = 0;
  int* M = new int[n + 1];
  for (int i = 0; i < n + 1; i++) M[i] = 0;

  int L = 0;
  for (int i = 0; i < n; i++) {
    int lo = 1, hi = L;
    while (lo <= hi) {
      int mid = ceil((lo + hi) / 2);
      if (Pred()(numVec[M[mid]], numVec[i])) { //compare
        lo = mid + 1;
      }
      else {
        hi = mid - 1;
      }
    }

    int newL = lo;
    P[i] =  M[newL - 1];
    M[newL] = i;

    if (newL > L) {
      L = newL;
    }
  }
  int k = M[L];
  posIndex.assign(L, 0);
  for (int i = L - 1; i >= 0; i--) {
    posIndex[i] = k;
    k = P[k];
  }
}


#endif //LIST_H_
