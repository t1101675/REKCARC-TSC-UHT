#ifndef LIS_H_
#define LIS_H_
#include <vector>


class LIS {
public:
  void solve(const std::vector<int>& numVec, std::vector<int>& posIndex);
};


#endif //LIS_H_
