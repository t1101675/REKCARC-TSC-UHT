#include "lis.h"
#include <iostream>
#include <cmath>
#include <vector>

void LIS::solve(const std::vector<int>& numVec, std::vector<int>& posIndex) {
  int n = numVec.size();
  int* P = new int[n];
  for (int i = 0; i < n; i++) P[i] = 0;
  int* M = new int[n + 1];
  for (int i = 0; i < n + 1; i++) M[i] = 0;

  int L = 0;
  for (int i = 0; i < n; i++) {
    int lo = 1, hi = L;
    while (lo <= hi) {
      int mid = ceil((lo + hi) / 2);
      if (numVec[M[mid]] < numVec[i]) {
        lo = mid + 1;
      }
      else {
        hi = mid - 1;
      }
    }

    int newL = lo;
    P[i] =  M[newL - 1];
    M[newL] = i;

    if (newL > L) {
      L = newL;
    }
  }
  int k = M[L];
  posIndex.assign(L, 0);
  for (int i = L - 1; i >= 0; i--) {
    posIndex[i] = k;
    k = P[k];
  }
}
