#ifndef MONITOR_H_
#define MONITOR_H_

class Monitor {
private:
  
};


#endif //MONITOR_H_
