#include <iostream>
#include <vector>
#include <cstdlib>
#include <iterator>
#include <algorithm>
#include <ctime>
#include "lis.h"
#include <windows.h>

using namespace std;

void GenRand(std::vector<int>& v) {
  srand(time(0));
  for (int i = 0; i < 20; i++) {
    v.push_back(rand() % 1001);
  }
}



int main() {
  vector<int> numVec;
  GenRand(numVec);
  LARGE_INTEGER winFreq;
  LARGE_INTEGER winStart;
  LARGE_INTEGER winNow;

  vector<int> posIndex;
  LIS lis;

  if (!QueryPerformanceFrequency(&winFreq))
    cout << "QueryPerformanceFrequency Failed.";

  if (!QueryPerformanceCounter(&winStart))
    cout << "QueryPerformanceCounter Failed.";
    lis.bp(numVec, posIndex);
  if (!QueryPerformanceCounter(&winNow))
    cout << "QueryPerformanceCounter Failed";
  double Runtime_bf = (double)(winNow.QuadPart - winStart.QuadPart) / (double)winFreq.QuadPart;

  if (!QueryPerformanceCounter(&winStart))
    cout << "QueryPerformanceCounter Failed.";
    lis.dp(numVec, posIndex);
  if (!QueryPerformanceCounter(&winNow))
    cout << "QueryPerformanceCounter Failed";
  double Runtime_dp = (double)(winNow.QuadPart - winStart.QuadPart) / (double)winFreq.QuadPart;

  //1000 ints are too many to count... it takes too much time
  std::cout << "The rate: \n" << (Runtime_bf - Runtime_dp) / Runtime_bf * 100 << "%"<< "\n";
  return 0;
}
