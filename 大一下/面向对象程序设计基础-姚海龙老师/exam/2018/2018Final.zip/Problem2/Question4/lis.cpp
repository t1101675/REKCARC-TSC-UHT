#include "lis.h"
#include <iostream>
#include <cmath>
#include <vector>

void LIS::solve(const std::vector<int>& numVec, std::vector<int>& posIndex) {
  int n = numVec.size();
  int* P = new int[n];
  for (int i = 0; i < n; i++) P[i] = 0;
  int* M = new int[n + 1];
  for (int i = 0; i < n + 1; i++) M[i] = 0;

  int L = 0;
  for (int i = 0; i < n; i++) {
    int lo = 1, hi = L;
    while (lo <= hi) {
      int mid = ceil((lo + hi) / 2);
      if (numVec[M[mid]] < numVec[i]) {
        lo = mid + 1;
      }
      else {
        hi = mid - 1;
      }
    }

    int newL = lo;
    P[i] =  M[newL - 1];
    M[newL] = i;

    if (newL > L) {
      L = newL;
    }
  }
  int k = M[L];
  posIndex.assign(L, 0);
  for (int i = L - 1; i >= 0; i--) {
    posIndex[i] = k;
    k = P[k];
  }
}

void LIS::bp(const std::vector<int>& numVec, std::vector<int>& posIndex) {
  std::vector<bool> select;
  select.assign(numVec.size(), 0);
  naive(numVec, posIndex, select, 0, 0);
}


void LIS::dp(const std::vector<int>& numVec, std::vector<int>& posIndex) {
  solve(numVec, posIndex);
}

void LIS::naive(const std::vector<int>& numVec, std::vector<int>& posIndex, std::vector<bool>& select, int max, int n) {
  if (n >= numVec.size()) {
    std::vector<int> newVec;
    for (int i = 0; i < select.size(); i++) {
      if (select[i]) {
        newVec.push_back(numVec[i]);
      }
    }

    for (int i = 0; i + 1< newVec.size(); i++) {
      if (newVec[i] >= newVec[i + 1]) {
        return;
      }
    }

    //OK
    if (newVec.size() > max) {
      max = newVec.size();
      posIndex.clear();
      for (int i = 0; i < select.size(); i++) {
        if (select[i]) {
          posIndex.push_back(i);
        }
      }
    }
  }
  else {
    select[n] = 0;
    naive(numVec, posIndex, select, max, n + 1);
    select[n] = 1;
    naive(numVec, posIndex, select, max, n + 1);
  }
}
