#ifndef LIS_H_
#define LIS_H_
#include <vector>


class LIS {
private:
  void naive(const std::vector<int>& numVec, std::vector<int>& posIndex, std::vector<bool>& select, int max, int n);
  void solve(const std::vector<int>& numVec, std::vector<int>& posIndex);
public:
  void dp(const std::vector<int>& numVec, std::vector<int>& posIndex);
  void bp(const std::vector<int>& numVec, std::vector<int>& posIndex);
};


#endif //LIS_H_
