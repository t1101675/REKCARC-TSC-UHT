#ifndef STUDENT_H_
#define STUDENT_H_

#include <iostream>

class Student {
private:
  int m_score1;
  int m_score2;
public:
  Student(int score1, int score2): m_score1(score1), m_score2(score2) {}
  int Score1() const { return m_score1; }
  int Score2() const { return m_score2; }

  friend bool operator< (const Student& s1, const Student& s2) {
    if (s1.m_score1 < s2.m_score1)
      return true;
    else if (s1.m_score1 == s2.m_score1) {
      if (s1.m_score2 < s2.m_score2)
        return true;
    }
    return false;
  }

  friend std::ostream& operator<< (std::ostream& out, const Student& s) {
    out << "(" << s.m_score1 << ", " << s.m_score2 << ")";
    return out;
  }
};

#endif //STUDENT_H_
