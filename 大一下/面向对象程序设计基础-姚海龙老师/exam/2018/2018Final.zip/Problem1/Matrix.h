#ifndef MATRIX_H_
#define MATRIX_H_

#include <iostream>
#include <fstream>
#include <string>

class Matrix {
private:
  int* m_data;
  int m_rowSize;
  int m_colSize;

  std::string m_fileName;
public:
  Matrix(): m_data(NULL), m_rowSize(0), m_colSize(0) {}
  Matrix(const std::string& fileName);
  Matrix(const Matrix& m);
  Matrix(const int* m, int rowSize, int colSize);
  Matrix& operator= (const Matrix& m);
  ~Matrix();
  int Get(int row, int col) const;
  void Set(int row, int col, int value);
  int RowSize() const { return m_rowSize; }
  int ColSize() const { return m_colSize; }
  friend std::ostream& operator<< (std::ostream& out, const Matrix& ma);
  friend bool operator<= (const Matrix& m1, const Matrix& m2);
  friend bool operator>= (const Matrix& m1, const Matrix& m2);
  friend bool operator== (const Matrix& m1, const Matrix& m2);

  friend Matrix operator+ (const Matrix& m1, const Matrix& m2);
  friend Matrix operator* (const Matrix& m1, const Matrix& m2);
};
#endif //MATRIX_H_
