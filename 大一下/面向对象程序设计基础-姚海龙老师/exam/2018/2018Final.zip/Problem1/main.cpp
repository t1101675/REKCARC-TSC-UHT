#include <iostream>
#include <fstream>
#include "Matrix.h"


int main() {
  Matrix a("./a.txt");
  std::ofstream fileout("./matrixA.txt");
  std::cout << "a: \n" << a << "\n";
  fileout << a;

  Matrix b("./b.txt");
  std::cout << "b: \n" << b << "\n";
  if (a <= b) {
    std::cout << "a is <= b" << std::endl;
  }
  if (a >= b) {
    std::cout << "a is >= b" << std::endl;
  }
  if (a == b) {
    std::cout << "a is == b" << std::endl;
  }

  Matrix d = a + b;
  std::cout << "d: \n" << d << "\n";
  Matrix c("./c.txt");
  std::cout << "c: \n" << c << "\n";
  Matrix e = a * c;
  std::cout << "e: \n" << e << "\n";
  e = b * c;
  std::cout << "e again: \n" << e << "\n";

  return 0;
}
