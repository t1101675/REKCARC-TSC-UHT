#include <fstream>
#include <iostream>
#include "Matrix.h"

Matrix::Matrix(const std::string& fileName) {
  std::ifstream fin;
  fin.open(fileName.c_str());
  fin >> m_rowSize;
  fin >> m_colSize;
  m_data = new int[m_rowSize * m_colSize];
  for (int i = 0; i < m_rowSize; i++) {
    for (int j = 0; j < m_colSize; j++) {
      fin >> m_data[i * m_colSize + j];
    }
  }
  fin.close();
}

int Matrix::Get(int row, int col) const {
  return m_data[row * m_colSize + col];
}

void Matrix::Set(int row, int col, int value) {
  m_data[row * m_colSize + col] = value;
}

Matrix::Matrix(const Matrix& m) {
  m_rowSize = m.m_rowSize;
  m_colSize = m.m_colSize;
  m_data = new int[m_rowSize * m_colSize];
  int max = m_rowSize * m_colSize;
  for (int i = 0; i < max; i++) {
    m_data[i] = m.m_data[i];
  }
}

Matrix::Matrix(const int* m, int rowSize, int colSize) {
  m_rowSize = rowSize;
  m_colSize = colSize;
  int max = m_rowSize * m_colSize;
  m_data = new int[max];
  for (int i = 0; i < max; i++) {
    m_data[i] = m[i];
  }
}

Matrix& Matrix::operator= (const Matrix& m) {
  if (this == &m) return *this;
  else {
    delete[] m_data;
    m_rowSize = m.m_rowSize;
    m_colSize = m.m_colSize;
    m_data = new int[m_rowSize * m_colSize];
    int max = m_rowSize * m_colSize;
    for (int i = 0; i < max; i++) {
      m_data[i] = m.m_data[i];
    }
  }
  return *this;
}

Matrix::~Matrix() {
  if (m_data) {
    delete[] m_data;
  }
}

std::ostream& operator<< (std::ostream& out, const Matrix& ma) {
  for (int i = 0; i < ma.m_rowSize; i++) {
    for (int j = 0; j < ma.m_colSize; j++) {
      out << ma.Get(i, j) << " ";
    }
    out << "\n";
  }
  return out;
}

bool operator<= (const Matrix& m1, const Matrix& m2) {
  if ((m1.m_rowSize != m2.m_rowSize) || (m1.m_colSize != m2.m_colSize)) {
    return false;
  }
  int max = m1.m_rowSize * m1.m_colSize;
  for (int i = 0; i < max; i++) {
    if (m1.m_data[i] > m2.m_data[i]) {
      return false;
    }
  }
  return true;
}

bool operator>= (const Matrix& m1, const Matrix& m2) {
  if ((m1.m_rowSize != m2.m_rowSize) || (m1.m_colSize != m2.m_colSize)) {
    return false;
  }
  int max = m1.m_rowSize * m1.m_colSize;
  for (int i = 0; i < max; i++) {
    if (m1.m_data[i] < m2.m_data[i]) {
      return false;
    }
  }
  return true;
}

bool operator== (const Matrix& m1, const Matrix& m2) {
  if ((m1.m_rowSize != m2.m_rowSize) || (m1.m_colSize != m2.m_colSize)) {
    return false;
  }
  int max = m1.m_rowSize * m1.m_colSize;
  for (int i = 0; i < max; i++) {
    if (m1.m_data[i] != m2.m_data[i]) {
      return false;
    }
  }
  return true;
}

Matrix operator+ (const Matrix& m1, const Matrix& m2) {
  if ((m1.m_rowSize != m2.m_rowSize) || (m1.m_colSize != m2.m_colSize)) {
    return Matrix();
  }
  int max = m1.m_rowSize * m1.m_colSize;
  int* m = new int[max];
  for (int i = 0; i < max; i++) {
    m[i] = m1.m_data[i] + m2.m_data[i];
  }
  return Matrix(m, m1.m_rowSize, m1.m_colSize);
}

Matrix operator* (const Matrix& m1, const Matrix& m2) {
  if ((m1.m_colSize != m2.m_rowSize)) {
    return Matrix();
  }
  int max = m1.m_rowSize * m2.m_colSize;
  int* m = new int[max];
  for (int i = 0; i < m1.m_rowSize; i++) {
    for (int j = 0; j < m2.m_colSize; j++) {
      int temp = 0;
      for (int k = 0; k < m1.m_colSize; k++) {
        temp += m1.Get(i, k) * m2.Get(k, j);
      }
      m[i * m2.m_colSize + j] = temp;
    }
  }
  return Matrix(m, m1.m_rowSize, m2.m_colSize);
}
