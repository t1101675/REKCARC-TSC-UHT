#ifndef SCORE_H_INCLUDED
#define SCORE_H_INCLUDED
#include <cstring>
#include <cstdlib>

class Score
{
public:
    Score(const char* name) {
        subjectName_ = new char[strlen(name)+1];
        strcpy(subjectName_, name);
		//strcpy_s(subjectName_,strlen(name)+1, name);
    }
    virtual float computeScore() = 0;
	virtual ~Score() { delete subjectName_; }
protected:
    char* subjectName_;
};


#endif // SCORE_H_INCLUDED
