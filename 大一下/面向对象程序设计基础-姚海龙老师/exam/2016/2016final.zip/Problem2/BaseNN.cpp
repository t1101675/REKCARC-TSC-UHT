#include "BaseNN.h"
#include "KDTree.h"
using namespace std;

//NOTE: here is definition of the constructor of BaseNearestNeighbor
BaseNearestNeighbor::BaseNearestNeighbor(std::vector<std::vector<int> > &points)
{
    //NOTE: add the points into the k-d tree one-by-one
	for (int i = 0; i < points.size(); i++) {
		tree_.add(points[i]);
	}
}

void BaseNearestNeighbor::search(std::vector<int> &pnt)
{
	tree_.findNearest(pnt, tree_.checkedNodes_);
	getNN(tree_.nearest_neighbour_.x_);
	getVisitedPoint(tree_.checkedNodes_);
    //NOTE: Call KDTree's findNearest() interface for finding the nearest multidimentional point to the given point pnt
    //Please fill in the code here
		
}
