#include "MyNN.h"
using namespace std;

//NOTE: need to add the overloaded stream operator << for MyNN

void MyNN::getNN(std::vector<int>& point)
{
	search(point);
}

void MyNN::getVisitedPoint(std::vector<int>& point)
{
}

ostream & operator<<(ostream & myOutput, const MyNN & m)
{
	for (int i = 0; i < m.nnPoint_.size(); i++)
		myOutput << m.nnPoint[i] << ' ';
	myOutput << endl;
	myOutput <<(int) m.visitedPoints_.size() << endl;
	for (int i = 0; i < m.visitedPoints_.size(); i++) {
		for (int j = 0; j < m.visitedPoints_.size(); j++)
			myOutput << m.visitedPoints_[i][j] << ' ';
		myOutput << endl;
	}
	return myOutput;

}
