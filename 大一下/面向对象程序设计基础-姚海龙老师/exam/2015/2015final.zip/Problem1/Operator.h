// Operator.h
#ifndef __OPERATOR_H
#define __OPERATOR_H

#include <cmath>
#include <fstream>
#include <string>
#include <vector>

class Operator {
protected:
	typedef double Float;
	std::vector<Float> numbers;
public:
	Operator(const std::string &str) {
		std::ifstream fin(str);
		Float x;
		while (fin >> x)
			numbers.push_back(x);
	}
	virtual Float calculate() const {
		return nan("should not use base object");
	}
} ;

#endif
