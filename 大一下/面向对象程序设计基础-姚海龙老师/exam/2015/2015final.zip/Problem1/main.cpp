#include <cstdio>
#include <string>
#include <iostream>
//HY: include header files here if needed
#include <cstring>
#include <fstream>
#include <random>

#include "Adder.h"
#include "Product.h"

using namespace std;

void test(Operator *calculator)
{
  printf("Output: %.5e\n", calculator->calculate());
}

void test(Operator calculator)
{
  printf("Output: %.5e\n", calculator.calculate());
}

//HY: implement 
void randomGen() {
  ofstream fout("./randInput.txt");
  mt19937 r{random_device{}()};
  uniform_real_distribution<double> distribution(0.0, 10.0);
  for (unsigned int i = 0; i < 10; ++i) {
    double x = distribution(r);
    if (i != 0) fout << " ";
    fout << x;
  }
  fout << endl;
  fout.close();
}

int main(int argc, char *argv[])
{
  //HY: use input.txt as input by default
  string inputFile = "./input.txt";
  
  //HY: add new code to check the command-line arguments, add one function here to randomly 
  //generate 10 floating numbers, and store the numbers into ./randInput.txt
  //Now set inputFile = ./randInput.txt
  //Call function randomGen(...);
  if (argc > 1 && !strcmp(argv[1], "-r")) {
    randomGen();
    inputFile = "./randInput.txt";
  }

  Adder add(inputFile);
  Product product(inputFile);
  
  test(add);
  test(product);

  test(&add);
  test(&product);

  return 0;
}
