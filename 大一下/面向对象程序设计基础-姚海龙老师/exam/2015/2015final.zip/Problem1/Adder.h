// Adder.h
#ifndef __ADDER_H
#define __ADDER_H

#include "Operator.h"

class Adder : public Operator {
	typedef Operator::Float Float;
public:
	Adder(const std::string &str) : Operator(str) {}
	Float calculate() const {
		Float result = 0.0;
		for (const Float &x : numbers)
			result += x;
		return result;
	}
} ;

#endif
