// Product.h
#ifndef __PRODUCT_H
#define __PRODUCT_H

#include "Operator.h"

class Product : public Operator {
	typedef Operator::Float Float;
public:
	Product(const std::string &str) : Operator(str) {}
	Float calculate() const {
		Float result = 1.0;
		for (const Float &x : numbers)
			result *= x;
		return result;
	}
} ;

#endif
