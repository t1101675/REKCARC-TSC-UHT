// Matrix.cpp
#include <cassert>
#include <cstring>
#include <iostream>

#include "Matrix.h"

using namespace std;

void Matrix::allocate() {
	this->arr = new int*[this->n];
	for (int i = 0; i < n; ++i)
		this->arr[i] = new int[this->m];
}

void Matrix::free() {
	for (int i = 0; i < this->n; ++i)
		delete[] this->arr[i];
	delete[] this->arr;
	arr = nullptr;
}

Matrix::Matrix() : n(0), m(0), arr(nullptr) {}

Matrix::Matrix(int _n, int _m) : n(_n), m(_m) {
	this->allocate();
}

Matrix::Matrix(const std::string &path) {
	ifstream fin(path);
	fin >> this->n >> this->m;
	this->allocate();
	for (int i = 0; i < this->n; ++i)
		for (int j = 0; j < this->m; ++j)
			fin >> this->arr[i][j];
	fin.close();
}

Matrix::Matrix(const Matrix &rhs) : n(rhs.n), m(rhs.m) {
	this->allocate();
	for (int i = 0; i < this->n; ++i)
		memcpy(this->arr[i], rhs.arr[i], sizeof(int) * this->m);
}

Matrix &Matrix::operator =(const Matrix &rhs) {
	if (this->arr != nullptr)
		this->free();
	this->n = rhs.n, this->m = rhs.m;
	this->allocate();
	for (int i = 0; i < this->n; ++i)
		memcpy(this->arr[i], rhs.arr[i], sizeof(int) * this->m);
	return *this;
}

void Matrix::load(const std::string &path) {
	if (this->arr != nullptr)
		this->free();
	ifstream fin(path);
	fin >> this->n >> this->m;
	this->allocate();
	for (int i = 0; i < this->n; ++i)
		for (int j = 0; j < this->m; ++j)
			fin >> this->arr[i][j];
	fin.close();
}

void Matrix::save(const std::string &path) {
	ofstream fout(path);
	fout << this->n << " " << this->m << endl;
	fout << *this;
	fout.close();
}

bool Matrix::operator <=(const Matrix &rhs) const {
	if (this->n != rhs.n || this->m != rhs.m) return false;
	for (int i = 0; i < this->n; ++i)
		for (int j = 0; j < this->m; ++j)
			if (!(this->arr[i][j] <= rhs.arr[i][j]))
				return false;
	return true;
}

bool Matrix::operator ==(const Matrix &rhs) const {
	if (this->n != rhs.n || this->m != rhs.m) return false;
	for (int i = 0; i < this->n; ++i)
		for (int j = 0; j < this->m; ++j)
			if (!(this->arr[i][j] == rhs.arr[i][j]))
				return false;
	return true;
}

bool Matrix::operator >=(const Matrix &rhs) const {
	if (this->n != rhs.n || this->m != rhs.m) return false;
	for (int i = 0; i < this->n; ++i)
		for (int j = 0; j < this->m; ++j)
			if (!(this->arr[i][j] >= rhs.arr[i][j]))
				return false;
	return true;
}

Matrix Matrix::operator +(const Matrix &rhs) const {
	assert(this->n == rhs.n && this->m == rhs.m);
	Matrix ret(this->n, this->m);
	for (int i = 0; i < this->n; ++i)
		for (int j = 0; j < this->m; ++j)
			ret.arr[i][j] = this->arr[i][j] + rhs.arr[i][j];
	return ret;
}

Matrix Matrix::operator *(const Matrix &rhs) const {
	assert(this->m == rhs.n);
	Matrix ret(this->n, rhs.m);
	for (int i = 0; i < this->n; ++i)
		for (int j = 0; j < rhs.m; ++j)
			for (int k = 0; k < this->m; ++k)
				ret.arr[i][j] += this->arr[i][k] * rhs.arr[k][j];
	return ret;
}

Matrix::~Matrix() {
	this->free();
}

ostream& operator <<(ostream &os, const Matrix &mat) {
	for (int i = 0; i < mat.n; ++i) {
		for (int j = 0; j < mat.m; ++j) {
			if (j != 0) os << " ";
			os << mat.arr[i][j];
		}
		os << endl;
	}
	return os;
}
