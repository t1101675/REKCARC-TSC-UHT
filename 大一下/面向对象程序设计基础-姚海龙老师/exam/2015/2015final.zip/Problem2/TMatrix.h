// TMatrix.h
#ifndef __TMATRIX_H
#define __TMATRIX_H

#include <cassert>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>

template<typename T>
class TMatrix {
	T **arr;
	int n, m;
	
	void allocate() {
		this->arr = new T*[this->n];
		for (int i = 0; i < n; ++i)
			this->arr[i] = new T[this->m];
	}
	void free() {
		for (int i = 0; i < this->n; ++i)
			delete[] this->arr[i];
		delete[] this->arr;
		arr = nullptr;
	}
public:
	const int &rows() const { return n; }
	const int &columns() const { return m; }
	T &operator ()(unsigned int i, unsigned int j) {
		assert(i < n && j < m);
		return arr[i][j];
	}
	const T &operator ()(unsigned int i, unsigned int j) const {
		assert(i < n && j < m);
		return arr[i][j];
	}
	
	TMatrix() : n(0), m(0), arr(nullptr) {}
	TMatrix(int _n, int _m) : n(_n), m(_m) {
		this->allocate();
	}
	TMatrix(const std::string &path) {
		std::ifstream fin(path);
		fin >> this->n >> this->m;
		this->allocate();
		for (int i = 0; i < this->n; ++i)
			for (int j = 0; j < this->m; ++j)
				fin >> this->arr[i][j];
		fin.close();
	}
	TMatrix(const TMatrix &rhs) : n(rhs.n), m(rhs.m) {
		this->allocate();
		for (int i = 0; i < this->n; ++i)
			for (int j = 0; j < this->m; ++j)
				this->arr[i][j] = rhs.arr[i][j];
	}
	TMatrix &operator =(const TMatrix &rhs) {
		if (this->arr != nullptr)
			this->free();
		this->n = rhs.n, this->m = rhs.m;
		this->allocate();
		for (int i = 0; i < this->n; ++i)
			for (int j = 0; j < this->m; ++j)
				this->arr[i][j] = rhs.arr[i][j];
		return *this;
	}
	
	void load(const std::string &path) {
		if (this->arr != nullptr)
			this->free();
		std::ifstream fin(path);
		fin >> this->n >> this->m;
		this->allocate();
		for (int i = 0; i < this->n; ++i)
			for (int j = 0; j < this->m; ++j)
				fin >> this->arr[i][j];
		fin.close();
	}
	void save(const std::string &path) {
		std::ofstream fout(path);
		fout << this->n << " " << this->m << std::endl;
		fout << *this;
		fout.close();
	}
	
	bool operator <=(const TMatrix &rhs) const {
		if (this->n != rhs.n || this->m != rhs.m) return false;
		for (int i = 0; i < this->n; ++i)
			for (int j = 0; j < this->m; ++j)
				if (!(this->arr[i][j] <= rhs.arr[i][j]))
					return false;
		return true;
	}
	bool operator ==(const TMatrix &rhs) const {
		if (this->n != rhs.n || this->m != rhs.m) return false;
		for (int i = 0; i < this->n; ++i)
			for (int j = 0; j < this->m; ++j)
				if (!(this->arr[i][j] == rhs.arr[i][j]))
					return false;
		return true;
	}
	bool operator >=(const TMatrix &rhs) const {
		if (this->n != rhs.n || this->m != rhs.m) return false;
		for (int i = 0; i < this->n; ++i)
			for (int j = 0; j < this->m; ++j)
				if (!(this->arr[i][j] >= rhs.arr[i][j]))
					return false;
		return true;
	}
	
	TMatrix operator +(const TMatrix &rhs) const {
		assert(this->n == rhs.n && this->m == rhs.m);
		TMatrix ret(this->n, this->m);
		for (int i = 0; i < this->n; ++i)
			for (int j = 0; j < this->m; ++j)
				ret.arr[i][j] = this->arr[i][j] + rhs.arr[i][j];
		return ret;
	}
	TMatrix operator *(const TMatrix &rhs) const {
		assert(this->m == rhs.n);
		TMatrix ret(this->n, rhs.m);
		for (int i = 0; i < this->n; ++i)
			for (int j = 0; j < rhs.m; ++j)
				for (int k = 0; k < this->m; ++k)
					ret.arr[i][j] += this->arr[i][k] * rhs.arr[k][j];
		return ret;
	}
	
	~TMatrix() {
		this->free();
	}
	
	template<typename Func>
	unsigned int countElements(const Func &f) const {
		unsigned int ret = 0;
		for (int i = 0; i < this->n; ++i)
			for (int j = 0; j < this->m; ++j)
				if (f(this->arr[i][j])) ++ret;
		return ret;
	}
	
	friend std::ostream& operator <<(std::ostream &os, const TMatrix &mat) {
		for (int i = 0; i < mat.n; ++i) {
			for (int j = 0; j < mat.m; ++j) {
				if (j != 0) os << " ";
				os << mat.arr[i][j];
			}
			os << std::endl;
		}
		return os;
	}
} ;

#endif
