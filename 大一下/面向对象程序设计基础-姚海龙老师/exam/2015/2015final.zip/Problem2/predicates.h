// predicates.h
#ifndef __PREDICATES_H
#define __PREDICATES_H

template<typename T>
bool isPositive(const T &x) {
	return x > 0;
}

template<typename T>
struct isPositiveFunctor {
	bool operator ()(const T &x) const {
		return x > 0;
	}
} ;

#endif
