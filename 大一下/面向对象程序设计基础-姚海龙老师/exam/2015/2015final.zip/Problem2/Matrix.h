// Matrix.h
#ifndef __MATRIX_H
#define __MATRIX_H

#include <fstream>
#include <string>

class Matrix {
	int **arr;
	int n, m;
	
	void allocate();
	void free();
public:
	const int &rows() const { return n; }
	const int &columns() const { return m; }
	int &operator ()(unsigned int i, unsigned int j) {
		assert(i < n && j < m);
		return arr[i][j];
	}
	const int &operator ()(unsigned int i, unsigned int j) const {
		assert(i < n && j < m);
		return arr[i][j];
	}
	
	Matrix();
	Matrix(int, int);
	Matrix(const std::string &);
	Matrix(const Matrix &);
	Matrix &operator =(const Matrix &);
	
	void load(const std::string &);
	void save(const std::string &);
	
	bool operator <=(const Matrix &) const;
	bool operator ==(const Matrix &) const;
	bool operator >=(const Matrix &) const;
	
	Matrix operator +(const Matrix &) const;
	Matrix operator *(const Matrix &) const;
	
	~Matrix();
	
	template<typename Func>
	unsigned int countElements(const Func &f) const {
		unsigned int ret = 0;
		for (int i = 0; i < this->n; ++i)
			for (int j = 0; j < this->m; ++j)
				if (f(this->arr[i][j])) ++ret;
		return ret;
	}
	
	friend std::ostream& operator <<(std::ostream &, const Matrix &);
} ;

#endif
