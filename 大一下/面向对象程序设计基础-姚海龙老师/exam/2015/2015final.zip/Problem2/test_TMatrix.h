// test_TMatrix.h
#include <cassert>
#include <iomanip>
#include <iostream>

#include "predicates.h"
#include "TMatrix.h"

void test_TMatrix() {
	using namespace std;
	
	TMatrix<double> a("aDouble.txt"), b(a), c;
	assert(a == b);
	c.load("bDouble.txt");
	
	if (a.rows() <= 20 && a.columns() <= 20) {
		cout << a << endl;
	}
	ofstream fileout("matrixA_double.txt");
	fileout << a << endl;
	fileout.close();
	a.save("matrixA_double_save.txt");
	TMatrix<double> f;
	f.load("matrixA_double_save.txt");
//	assert(a == f);		// assertion would fail due to precision problems
	
	if (a == b) {
		cout << "a is == b" << endl;
	}
	if (a <= b) {
		cout << "a is <= b" << endl;
	}
	if (a >= b) {
		cout << "a is >= b" << endl;
	}
	if (a == c) {
		cout << "a is == c" << endl;
	} else {
		cout << "a is not == c" << endl;
	}
	if (a == f) {	// result is false due to precision problems
		cout << "a is == f" << endl;
	} else {
		cout << "a is not == f" << endl;
	}
	cout << endl;
	
	TMatrix<double> d = a + b;
	TMatrix<double> e = a * c;
	e = b * c;
	e.save("aXb_double.txt");
	if (d.rows() <= 20 && d.columns() <= 20) {
		cout << d << endl;
	}
	if (e.rows() <= 20 && e.columns() <= 20) {
		cout << e << endl;
	}
	
	int positiveElems = a.countElements(isPositive<double>);
	cout << positiveElems << " elements are positive in a" << endl;
	int positiveElems_functor = a.countElements(isPositiveFunctor<double>());
	cout << positiveElems << " elements are positive in a (results yield by functor)" << endl;
	auto greaterThanOne = [](double x) -> bool { return x > 1.0; };
	int gt1Elems = e.countElements(greaterThanOne);
	cout << gt1Elems << " elements are greather than 1 in e" << endl;
}
