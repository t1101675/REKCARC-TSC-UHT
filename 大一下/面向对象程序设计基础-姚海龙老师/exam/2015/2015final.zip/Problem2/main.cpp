// main.cpp
#include <cassert>
#include <iostream>

#include "Matrix.h"
#include "predicates.h"
#include "test_TMatrix.h"

using namespace std;

int main() {
	
	Matrix a("a.txt"), b(a), c;
	assert(a == b);
	c.load("b.txt");
	
	if (a.rows() <= 20 && a.columns() <= 20) {
		cout << a << endl;
	}
	ofstream fileout("matrixA.txt");
	fileout << a << endl;
	fileout.close();
	a.save("matrixA_save.txt");
	Matrix f;
	f.load("matrixA_save.txt");
	assert(a == f);
	
	if (a == b) {
		cout << "a is == b" << endl;
	}
	if (a <= b) {
		cout << "a is <= b" << endl;
	}
	if (a >= b) {
		cout << "a is >= b" << endl;
	}
	if (a == c) {
		cout << "a is == c" << endl;
	} else {
		cout << "a is not == c" << endl;
	}
	cout << endl;
	
	Matrix d = a + b;
	Matrix e = a * c;
	e = b * c;
	e.save("aXb.txt");
	if (d.rows() <= 20 && d.columns() <= 20) {
		cout << d << endl;
	}
	if (e.rows() <= 20 && e.columns() <= 20) {
		cout << e << endl;
	}
	
	int positiveElems = a.countElements(isPositive<int>);
	cout << positiveElems << " elements are positive in a" << endl;
	int positiveElems_functor = a.countElements(isPositiveFunctor<int>());
	cout << positiveElems << " elements are positive in a (results yield by functor)" << endl;
	auto isOdd_int = [](int x) -> bool { return x % 2 == 1; };
	int oddElems = a.countElements(isOdd_int);
	cout << oddElems << " elements are odd in a" << endl;
	
	cout << endl << "Testing TMatrix<double>:" << endl;
	test_TMatrix();
	
	return 0;
}
