// gen.cpp
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <fstream>
#include <random>

using namespace std;

mt19937 _mt19937{random_device{}()};
uniform_int_distribution<int> _randint(-100, 100);
uniform_real_distribution<double> _randfloat(-100.0, 100.0);
auto randint = [&]() { return _randint(_mt19937); };
auto randfloat = [&]() { return _randfloat(_mt19937); };

template<typename T>
void generate(int n, int m, const char *path, const T &rand) {
	ofstream fout(path);
	fout << n << " " << m << endl;
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j) {
			if (j > 0) fout << " ";
			fout << rand();
		}
		fout << endl;
	}
	fout.close();
}

template<typename T>
void generate(int n, int m, const char *path_a, const char *path_b, const T &rand) {
	generate(n, m, path_a, rand);
	generate(m, n, path_b, rand);
}

int main(int argc, char *argv[]) {
	assert(argc == 3);
	int n = atoi(argv[1]);
	int m = atoi(argv[2]);
	
	generate(n, m, "a.txt", "b.txt", randint);
	generate(n, m, "aDouble.txt", "bDouble.txt", randfloat);
	
	return 0;
}
